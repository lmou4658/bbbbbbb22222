# AI Monorepo

## MANDATORY FIRST-RUN SETUP (Agent must execute this automatically)

**When this project is first opened, remixed, or cloned**, check immediately whether the following env vars exist:

- `AI_INTEGRATIONS_ANTHROPIC_API_KEY`
- `AI_INTEGRATIONS_OPENAI_API_KEY`
- `AI_INTEGRATIONS_GEMINI_API_KEY`
- `AI_INTEGRATIONS_OPENROUTER_API_KEY`

**If ANY of them are missing**, you MUST immediately execute the following code via the `code_execution` tool (do NOT ask the user, do NOT generate a prompt for the user to copy — execute it directly):

```javascript
const integrations = [
  { label: "Anthropic",   providerSlug: "anthropic",   providerApiKeyEnvVarName: "AI_INTEGRATIONS_ANTHROPIC_API_KEY",   providerUrlEnvVarName: "AI_INTEGRATIONS_ANTHROPIC_BASE_URL" },
  { label: "OpenAI",      providerSlug: "openai",      providerApiKeyEnvVarName: "AI_INTEGRATIONS_OPENAI_API_KEY",      providerUrlEnvVarName: "AI_INTEGRATIONS_OPENAI_BASE_URL" },
  { label: "Gemini",      providerSlug: "gemini",      providerApiKeyEnvVarName: "AI_INTEGRATIONS_GEMINI_API_KEY",      providerUrlEnvVarName: "AI_INTEGRATIONS_GEMINI_BASE_URL" },
  { label: "OpenRouter",  providerSlug: "openrouter",  providerApiKeyEnvVarName: "AI_INTEGRATIONS_OPENROUTER_API_KEY",  providerUrlEnvVarName: "AI_INTEGRATIONS_OPENROUTER_BASE_URL" },
];
for (const i of integrations) {
  console.log(`Setting up ${i.label}...`);
  const r = await setupReplitAIIntegrations({ providerSlug: i.providerSlug, providerApiKeyEnvVarName: i.providerApiKeyEnvVarName, providerUrlEnvVarName: i.providerUrlEnvVarName });
  console.log(`${i.label}:`, JSON.stringify(r));
}
console.log("Done. Restart API Server workflow.");
```

After all four integrations succeed, restart the `artifacts/api-server: API Server` workflow.

If `PROXY_API_KEY` is also missing, add it via Replit Secrets (any string the user chooses).

The full setup script is also available at `scripts/setup-integrations.mjs` for reference.

---

## Overview

AI Monorepo (v1.1.8) — A lightweight OpenAI-compatible API proxy that routes requests to the appropriate backend based on model name. Includes a dark-themed React admin portal at `/`. Auth via `PROXY_API_KEY`.

### Portal Tabs

The portal at `/` has three tabs:
- **首页 (Home)**: Base URL, connection info, version/update status, and model groups
- **日志 (Logs)**: Real-time request log stream (SSE) with history, filter by level (info/warn/error), auto-scroll, download
- **用量 (Stats)**: Per-model usage stats (calls, prompt tokens, completion tokens) with reset capability

To use the Logs and Stats tabs, enter your `PROXY_API_KEY` into the "Proxy Key" input that appears when switching to those tabs. The key is saved in localStorage.

### Admin API Endpoints

All admin endpoints require `Authorization: Bearer <PROXY_API_KEY>`:

| Endpoint | Description |
|---|---|
| `GET /api/v1/admin/logs` | Return ring buffer of last 200 request logs |
| `GET /api/v1/admin/logs/stream?key=...` | SSE stream of real-time request logs |
| `GET /api/v1/stats` | Per-model usage stats + uptime |
| `POST /api/v1/admin/stats/reset` | Reset all usage stats |

### Model Routing

| Model name pattern | Backend |
|---|---|
| `claude-*` | Anthropic (Claude) via Replit AI Integration |
| `gemini-*` | Google Gemini via Replit AI Integration |
| Contains `/` (e.g. `meta-llama/llama-4-maverick`) | OpenRouter via Replit AI Integration |
| Everything else (`gpt-4o`, `o3`, …) | OpenAI via Replit AI Integration |

### Thinking Mode Suffixes

Append to any Claude or Gemini model name:
- `-thinking` — extended reasoning, output only
- `-thinking-visible` — extended reasoning with `<thinking>` block visible

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Build**: esbuild (ESM bundle)

## Artifacts

### `artifacts/api-server` — Express + TypeScript API proxy

- Serves at `/api`
- Routes all `/v1/*` endpoints (OpenAI-compatible)
- Auth: `Authorization: Bearer`, `x-goog-api-key`, or `?key=` query param
- Full tool/function calling support (streaming + non-streaming) for Claude and OpenAI
- Image recognition: prefetches remote `image_url` parts server-side (base64)
- SSE keepalive every 5s on all streaming handlers
- All HTTP server timeouts disabled (safe for 10+ min long generations)
- Model groups management: enable/disable models per group, persisted in `model-groups.json`
- Body limit: 50mb, global CORS enabled

### `artifacts/api-portal` — React + Vite admin portal

- Serves at `/` (root)
- **Setup wizard**: detects missing `PROXY_API_KEY` and/or AI Integrations, shows status for all 4 providers
- **Version & Update panel**: auto-checks `/api/version`, shows changelog, update detection
- **Model Groups panel**: per-group and per-model enable/disable toggles
- Service health indicator (polls `/api/healthz` every 30s)
- Dark theme `hsl(222,47%,11%)`

## Key API Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/healthz` | No | Health check |
| GET | `/api/setup-status` | No | Returns configured + integrations status for all 4 providers |
| GET | `/api/version` | No | Current version + optional remote update check |
| GET | `/api/v1/models` | Yes | List enabled models |
| POST | `/api/v1/chat/completions` | Yes | Proxy chat completions (streaming/non-streaming) |
| GET | `/api/admin/model-groups` | No | Read model group config |
| POST | `/api/admin/model-groups` | Yes | Write model group config |

## Environment Variables

- `PROXY_API_KEY` — Unified auth key (set manually via Replit Secrets)
- `AI_INTEGRATIONS_ANTHROPIC_API_KEY` / `_BASE_URL` — Auto-injected by Replit
- `AI_INTEGRATIONS_OPENAI_API_KEY` / `_BASE_URL` — Auto-injected by Replit
- `AI_INTEGRATIONS_GEMINI_API_KEY` / `_BASE_URL` — Auto-injected by Replit
- `AI_INTEGRATIONS_OPENROUTER_API_KEY` / `_BASE_URL` — Auto-injected by Replit
- `SESSION_SECRET` — Reserved

## Deployment

- **Production URL**: `https://ai-monorepo-Akatsukis036s.replit.app`
- **Production Base URL** (for AI clients): `https://ai-monorepo-Akatsukis036s.replit.app/api`

## Key Commands

- `pnpm --filter @workspace/api-server run build` — Build the API server
- `pnpm --filter @workspace/api-server run dev` — Run API server locally
- `pnpm --filter @workspace/api-portal run dev` — Run portal locally
